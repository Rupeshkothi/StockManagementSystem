package com.abridged.stockmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
