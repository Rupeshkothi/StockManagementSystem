package com.abridged.stockmanagementsystem.exception;

public class ManagerIDFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}