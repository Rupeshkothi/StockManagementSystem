package com.abridged.stockmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockmanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockmanagementsystemApplication.class, args);
		
		
	}

}
