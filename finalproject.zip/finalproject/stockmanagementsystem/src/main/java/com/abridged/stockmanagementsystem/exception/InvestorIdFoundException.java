package com.abridged.stockmanagementsystem.exception;

public class InvestorIdFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}